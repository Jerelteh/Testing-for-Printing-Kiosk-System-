package my.edu.utar;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;

@RunWith(JUnitParamsRunner.class)
public class chargeTest {
	Order order = new Order();
	Charge charge = new Charge();
	
	//Test charge for document type
	private Object[] getParamsTestDocumentCharge() {
		return new Object[] {
			new Object[] {"black", 3, 1.5},
			new Object[] {"black", 7, 2.8},
			new Object[] {"black", 15, 4.5},
			new Object[] {"black", 30, 6.0},
			new Object[] {"color", 3, 3.0},
			new Object[] {"color", 7, 6.3},
			new Object[] {"color", 15, 12.0},
			new Object[] {"color", 30, 21.0},
		};
	}
	
	
	@Test
	@Parameters(method = "getParamsTestDocumentCharge")
	public void testDocumentCharge(String option, int quantity, double ER) {
		double AR = charge.calculateDocumentCharge(option, quantity);
		assertEquals(ER, AR, 0.01);
	}
	
	//Test valid charge for photo type without addition option
	private Object[] getParamsTestPhotoChargeWithoutAdditionOption() {
		return new Object[] {
			new Object[] {"normal", 3, null, 3.00},
			new Object[] {"normal", 7, null, 6.30},
			new Object[] {"normal", 15, null, 11.25},
			new Object[] {"normal", 30, null, 15.00},
			new Object[] {"passport", 3, null, 3.60},
			new Object[] {"passport", 7, null, 6.65},
			new Object[] {"passport", 15, null, 12.75},
			new Object[] {"passport", 30, null, 22.50},
		};
	}
	
	@Test
	@Parameters(method = "getParamsTestPhotoChargeWithoutAdditionOption")
	public void testPhotoChargeWithoutAdditionOption(String option, int quantity, String additionOption, double ER) {
		double AR = charge.calculatePhotoCharge(option, quantity, additionOption);
		assertEquals(ER, AR, 0.01);
	}

	//Test valid charge for photo type with addition option
	private Object[] getParamsTestPhotoChargeWithAdditionOption() {
		return new Object[] {
			new Object[] {"normal", 3, "HQ", 3.30},
			new Object[] {"normal", 7, "HQ", 7.00},
			new Object[] {"normal", 15, "HQ", 12.75},
			new Object[] {"normal", 30, "HQ", 18.00},
			new Object[] {"normal", 3, "DE", 3.45},
			new Object[] {"normal", 7, "DE", 7.35},
			new Object[] {"normal", 15, "DE", 13.50},
			new Object[] {"normal", 30, "DE", 19.50},
			new Object[] {"normal", 3, "BOTH", 3.75},
			new Object[] {"normal", 7, "BOTH", 8.05},
			new Object[] {"normal", 15, "BOTH", 15.00},
			new Object[] {"normal", 30, "BOTH", 22.50},
			new Object[] {"passport", 3, "HQ", 3.90},
			new Object[] {"passport", 7, "HQ", 7.35},
			new Object[] {"passport", 15, "HQ", 14.25},
			new Object[] {"passport", 30, "HQ", 25.50},
			new Object[] {"passport", 3, "DE", 4.05},
			new Object[] {"passport", 7, "DE", 7.70},
			new Object[] {"passport", 15, "DE", 15.00},
			new Object[] {"passport", 30, "DE", 27.00},
			new Object[] {"passport", 3, "BOTH", 4.35},
			new Object[] {"passport", 7, "BOTH", 8.40},
			new Object[] {"passport", 15, "BOTH", 16.50},
			new Object[] {"passport", 30, "BOTH", 30.00},
		};
	}
	
	@Test
	@Parameters(method = "getParamsTestPhotoChargeWithAdditionOption")
	public void testPhotoChargeWithAdditionOption(String option, int quantity, String additionOption, double ER) {
		double AR = charge.calculatePhotoCharge(option, quantity, additionOption);
		assertEquals(ER, AR, 0.01);
	}
	
	//Calculate total charge for all printing request
	@Test
	public void testTotalCharge() {
		Order order = new Order();
		Charge charge = new Charge();
		
        order.processOrderEntry("document", "black", 3, null); //RM1.5
        order.processOrderEntry("document", "black", 7, null); //RM2.8
        order.processOrderEntry("document", "color", 15, null); //RM12
        order.processOrderEntry("document", "color", 30, null); //RM21
        order.processOrderEntry("photo", "normal", 7, "HQ"); //RM7.0
        order.processOrderEntry("photo", "normal", 15, "HQ"); //RM12.75
        order.processOrderEntry("photo", "passport", 3, "DE"); //RM4.05
        order.processOrderEntry("photo", "passport", 30, "BOTH"); //RM30
        
        double ER = 91.1;
        double AR = charge.calculateTotalCharge(order.getPrintingRequest());
		assertEquals(ER, AR, 0.01);
	}
	
	//Test the charge module can pass correct printing requests to printing module
	//Test the printing module can get correct printing requests from charge module
	//Test the queueRequest() method in printing module was called for each printing request in the request list
	@Test
	public void testPassRequestToPrinterMockito() {
        order.processOrderEntry("document", "color", 10, null);
        order.processOrderEntry("photo", "normal", 10, null);
        List<PrintingRequest> requestList = order.getPrintingRequest();
        
		PhotoPrinter printerMock = mock(PhotoPrinter.class);
		charge.passPrintingRequestsToPrintingModule(requestList, printerMock);
		verify(printerMock, times(requestList.size())).queueRequest(any(PrintingRequest.class));
	}
	
	@Test
	public void testPassRequestToPrinterTestDouble() {
		List<PrintingRequest> requestList = Arrays.asList(
		    new PrintingRequest("document", "black", 10, null),
		    new PrintingRequest("photo", "normal", 5, "hq")
		);
		
		PhotoPrinterStub pps = new PhotoPrinterStub();
		PhotoPrinter printerStub = new PhotoPrinter(pps);
	    charge.passPrintingRequestsToPrintingModule(requestList, printerStub);
	    List<PrintingRequest> queuedRequests = pps.getQueue();
	    assertEquals(requestList, queuedRequests);
	}
	
	//Read test value from text file
	@Test
	public void testValueReadFromTextFile1() {
		Order order = new Order();
		Charge charge = new Charge();
		
		ArrayList<String[]> linesRead = new ArrayList<String[]>();
		String fileName = "values.txt";
		Scanner inputStream = null;
		
		try {
			inputStream = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e) {
			System.out.println("Error opening the file " + fileName);
			System.exit(0);
		}
		
		while (inputStream.hasNextLine()) {
			String singleLine = inputStream.nextLine();
			String[] tokens = singleLine.split(" ");
			linesRead.add(tokens);
		}

		for (String[] strArray : linesRead) {
			for (int i = 0; i < strArray.length; i++) {
				System.out.print(strArray[i] + " ");
			}
			int quantity = Integer.parseInt(strArray[2]);
			order.processOrderEntry(strArray[0], strArray[1], quantity, strArray[3]);
			System.out.println();
		}

		inputStream.close();
        
        double ER = 91.1;
        double AR = charge.calculateTotalCharge(order.getPrintingRequest());
		assertEquals(ER, AR, 0.01);
	}
	
	@Test
	public void testIntegration() {
	    PhotoPrinterStub printerStub = new PhotoPrinterStub();
	    PhotoPrinter printer = new PhotoPrinter(printerStub);
	    Order order = new Order();
	    Charge charge = new Charge();
	    // Create a printing request
	    PrintingRequest request = new PrintingRequest("photo", "normal", 7, "hq");

	    // Submit the printing request
	    order.addPrintingRequest(request);
	    order.passOrder(charge);
	    printer.queueRequest(request);

	    // Check that the request was added to the printer queue
	    assertEquals(1, printerStub.getQueue().size());

	    // Check that the total charge was calculated correctly
	    List<PrintingRequest> requestList = order.getPrintingRequest();
	    double actualCharge = charge.calculateTotalCharge(requestList);
	    double expectedCharge = 7.00;
	    assertEquals(expectedCharge, actualCharge, 0.01);
	}
}
