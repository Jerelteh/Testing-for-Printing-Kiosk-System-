package my.edu.utar;

import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

@RunWith(JUnitParamsRunner.class)
public class orderTest {
	Order order = new Order();
	
	//Test valid order
	private Object[] getParamsTestValidOrder() {
		return new Object[] {
			new Object[] {"Document", "color", 3, null},
			new Object[] {"Document", "color", 7, null},
			new Object[] {"Document", "color", 15, null},
			new Object[] {"Document", "color", 30, null},
			new Object[] {"Document", "black", 3, null},
			new Object[] {"Document", "black", 7, null},
			new Object[] {"Document", "black", 15, null},
			new Object[] {"Document", "black", 30, null},
			new Object[] {"Photo", "normal", 3, null},
			new Object[] {"Photo", "normal", 7, "HQ"},
			new Object[] {"Photo", "normal", 15, "DE"},
			new Object[] {"Photo", "normal", 30, "Both"},
			new Object[] {"Photo", "passport", 3, null},
			new Object[] {"Photo", "passport", 7, "HQ"},
			new Object[] {"Photo", "passport", 15, "DE"},
			new Object[] {"Photo", "passport", 30, "Both"},
		};
	}
	
	@Test
	@Parameters(method = "getParamsTestValidOrder")
	public void testValidOrderEntry(String type, String option, int quantity, String additionOption) {
		PrintingRequest request = order.processOrderEntry(type, option, quantity, additionOption);
        assertEquals(type, request.getType());
        assertEquals(option, request.getOption());
        assertEquals(additionOption, request.getAdditionOption());
        assertEquals(quantity, request.getQuantity());
	}
	
	//Test invalid order type
	private Object[] getParamsTestInvalidOrderType() {
		return new Object[] {
			new Object[] {"Book", "Black", 3, null},
			new Object[] {"", "Black", 7, null},
			new Object[] {"1234", "Color", 15, null},
			new Object[] {"Doc!ment", "Normal", 20, null},
		};
	}
	
	@Test(expected=IllegalArgumentException.class)
	@Parameters(method = "getParamsTestInvalidOrderType")
	public void testInvalidOrderType(String type, String option, int quantity, String additionOption) {
		order.processOrderEntry(type, option, quantity, additionOption);
	}
	
	//Test invalid order option
	private Object[] getParamsTestInvalidOrderOption() {
		return new Object[] {
			new Object[] {"Document", "Poster", 3, null},
			new Object[] {"Document", "", 7, null},
			new Object[] {"Photo", "25", 15, null},
			new Object[] {"Photo", "Pas$port", 30, null},
		};
	}
	
	@Test(expected=IllegalArgumentException.class)
	@Parameters(method = "getParamsTestInvalidOrderOption")
	public void testInvalidOrderOption(String type, String option, int quantity, String additionOption) {
		order.processOrderEntry(type, option, quantity, additionOption);
	}
	
	//Test invalid order quantity
	private Object[] getParamsTestInvalidOrderQuantity() {
		return new Object[] {
			new Object[] {"Document", "black", -5, null},
			new Object[] {"Document", "black", 60, null},
			new Object[] {"Document", "color", -5, null},
			new Object[] {"Document", "color", 60, null},
			new Object[] {"Photo", "normal", -5, null},
			new Object[] {"Photo", "normal", 60, null},
			new Object[] {"Photo", "passport", -5, null},
			new Object[] {"Photo", "passport", 60, null},
		};
	}
	
	@Test(expected=IllegalArgumentException.class)
	@Parameters(method = "getParamsTestInvalidOrderQuantity")
	public void testInvalidOrderQuantity(String type, String option, int quantity, String additionOption) {
		order.processOrderEntry(type, option, quantity, additionOption);
	}
	
	//Test invalid order additional option
	private Object[] getParamsTestInvalidOrderAdditionOption() {
		return new Object[] {
			new Object[] {"Photo", "Passport", 30, "LQ"},
			new Object[] {"Photo", "Normal", 5, "123"},
			new Object[] {"Photo", "Passport", 15, ""},
			new Object[] {"Photo", "Normal", 30, "H@"},
		};
	}
	
	@Test(expected=IllegalArgumentException.class)
	@Parameters(method = "getParamsTestInvalidOrderAdditionOption")
	public void testInvalidOrderAdditionOption(String type, String option, int quantity, String additionOption) {
		order.processOrderEntry(type, option, quantity, additionOption);
	}
	
	// verify the order module pass correct order details to charge module
	// verify the charge module get correct order details from order module
	@Test
    public void testPassOrder() {
        Charge mockCharge = mock(Charge.class);
        
        order.processOrderEntry("document", "color", 10, null);
        order.processOrderEntry("photo", "normal", 10, null);
        order.passOrder(mockCharge);
        verify(mockCharge).calculateTotalCharge(order.getPrintingRequest());
    }
	
	//Read test value from text file
	@Test
	public void testValueReadFromTextFile() {
		ArrayList<String[]> linesRead = new ArrayList<String[]>();
		String fileName = "input.txt";
		Scanner inputStream = null;
		
		try {
			inputStream = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e) {
			System.out.println("Error opening the file " + fileName);
			System.exit(0);
		}
		
		while (inputStream.hasNextLine()) {
			String singleLine = inputStream.nextLine();
			String[] tokens = singleLine.split(" ");
			linesRead.add(tokens);
		}

		for (String[] strArray : linesRead) {
			for (int i = 0; i < strArray.length; i++) {
				System.out.print(strArray[i] + " ");
			}
			String type = strArray[0];
	        String option = strArray[1];
			int quantity = Integer.parseInt(strArray[2]);
			String additionOption = strArray[3];
			
			PrintingRequest request = order.processOrderEntry(type, option, quantity, additionOption);
			assertEquals(type, request.getType());
	        assertEquals(option, request.getOption());
	        assertEquals(quantity, request.getQuantity());
	        assertEquals(additionOption, request.getAdditionOption());
			System.out.println();
		}
		inputStream.close();
	}
}
