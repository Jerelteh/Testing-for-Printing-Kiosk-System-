package my.edu.utar;

import java.util.List;

public class Charge {
	
	public Charge() {
    }
	
	public double calculateTotalCharge(List<PrintingRequest> requestList) {
		double totalCharge = 0.0;
		
		for (PrintingRequest printingRequest : requestList) {
			if (printingRequest.getType().equalsIgnoreCase("document")) {
				totalCharge += calculateDocumentCharge(printingRequest.getOption(), printingRequest.getQuantity());
			}
			else if(printingRequest.getType().equalsIgnoreCase("photo")) {
				totalCharge += calculatePhotoCharge(printingRequest.getOption(), printingRequest.getQuantity(), printingRequest.getAdditionOption());
			}
		}
		
		return totalCharge;
	}
	
	public double calculateDocumentCharge(String option, int quantity) {
        double charge = 0.0;
        
		if(option.equalsIgnoreCase("black")){
        	if (quantity < 5) {
                charge = quantity * 0.5;
            }
        	else if (quantity <= 10) {
            	charge = quantity * 0.4;
            }
        	else if (quantity <= 20) {
            	charge = quantity * 0.3;
            }
        	else if (quantity <= 50) {
            	charge = quantity * 0.2;
            }
        }
		else if(option.equalsIgnoreCase("color")) {
	        if (quantity < 5) {
	        	charge = quantity * 1.0;
	        }
	        else if (quantity <= 10) {
	           	charge = quantity * 0.9;
	        }
	        else if (quantity <= 20) {
	            charge = quantity * 0.8;
	        }
	        else if (quantity <= 50) {
	           	charge = quantity * 0.7;
	        }
	    }
        return charge;
    }
	
	public double calculatePhotoCharge(String option, int quantity, String additionOption) {
        double charge = 0.0;
        
    	if(additionOption == null){
	         if(option.equalsIgnoreCase("normal")){
	        	if (quantity < 5) {
	                charge = quantity * 1.0;
	            } 
	        	else if (quantity <= 10) {
	            	charge = quantity * 0.9;
	            } 
	        	else if (quantity <= 20) {
	            	charge = quantity * 0.75;
	            } 
	        	else if (quantity <= 50) {
	            	charge = quantity * 0.5;
	            }
	        }
	         else if(option.equalsIgnoreCase("passport")) {
			    if (quantity < 5) {
			       	charge = quantity * 1.2;
			    } 
			    else if (quantity <= 10) {
			       	charge = quantity * 0.95;
			    } 
			    else if (quantity <= 20) {
			       	charge = quantity * 0.85;
			    } 
			    else if (quantity <= 50) {
			        charge = quantity * 0.75;
			    } 
	        }
    	}
    	else if(additionOption.equalsIgnoreCase("HQ")){
    		if(option.equalsIgnoreCase("normal")){
    			if (quantity < 5) {
	                charge = quantity * (1.0 + 0.1);
	            } 
	        	else if (quantity <= 10) {
	            	charge = quantity * (0.9 + 0.1);
	            } 
	        	else if (quantity <= 20) {
	            	charge = quantity * (0.75 + 0.1);
	            } 
	        	else if (quantity <= 50) {
	            	charge = quantity * (0.5 + 0.1);
	            }
	        }
	         else if(option.equalsIgnoreCase("passport")) {
	        	if (quantity < 5) {
	        		charge = quantity * (1.2 + 0.1);
	            } 
	        	else if (quantity <= 10) {
	            	charge = quantity * (0.95 + 0.1);
	            } 
	        	else if (quantity <= 20) {
	            	charge = quantity * (0.85 + 0.1);
	            } 
	        	else if (quantity <= 50) {
	            	charge = quantity * (0.75 + 0.1);
	            }
	        }
    	}
    	else if(additionOption.equalsIgnoreCase("DE")){
    		if(option.equalsIgnoreCase("normal")){
    			if (quantity < 5) {
	                charge = quantity * (1.0 + 0.15);
	            } 
	        	else if (quantity <= 10) {
	            	charge = quantity * (0.9 + 0.15);
	            } 
	        	else if (quantity <= 20) {
	            	charge = quantity * (0.75 + 0.15);
	            } 
	        	else if (quantity <= 50) {
	            	charge = quantity * (0.5 + 0.15);
	            }
	        }
	         else if(option.equalsIgnoreCase("passport")) {
	        	if (quantity < 5) {
	        		charge = quantity * (1.2 + 0.15);
	            } 
	        	else if (quantity <= 10) {
	            	charge = quantity * (0.95 + 0.15);
	            } 
	        	else if (quantity <= 20) {
	            	charge = quantity * (0.85 + 0.15);
	            } 
	        	else if (quantity <= 50) {
	            	charge = quantity * (0.75 + 0.15);
	            }
	        }
    	}
    	else if(additionOption.equalsIgnoreCase("Both")){
    		if(option.equalsIgnoreCase("normal")){
    			if (quantity < 5) {
	                charge = quantity * (1.0 + 0.25);
	            } 
	        	else if (quantity <= 10) {
	            	charge = quantity * (0.9 + 0.25);
	            } 
	        	else if (quantity <= 20) {
	            	charge = quantity * (0.75 + 0.25);
	            } 
	        	else if (quantity <= 50) {
	            	charge = quantity * (0.5 + 0.25);
	            }
	        }
	         else if(option.equalsIgnoreCase("passport")) {
	        	if (quantity < 5) {
	        		charge = quantity * (1.2 + 0.25);
	            } 
	        	else if (quantity <= 10) {
	            	charge = quantity * (0.95 + 0.25);
	            } 
	        	else if (quantity <= 20) {
	            	charge = quantity * (0.85 + 0.25);
	            } 
	        	else if (quantity <= 50) {
	            	charge = quantity * (0.75 + 0.25);
	            }
	        }
    	}
    	return charge;
    }
	
	public void passPrintingRequestsToPrintingModule(List<PrintingRequest> requestList, PhotoPrinter printer) {
        for (PrintingRequest printingRequest : requestList) {
            PhotoPrinter photoPrinter = printer;
            photoPrinter.queueRequest(printingRequest);
        }
    }
}