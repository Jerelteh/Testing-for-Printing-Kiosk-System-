package my.edu.utar;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Order {
	private List<PrintingRequest> requestList = new ArrayList<>();
	
	public PrintingRequest getPrintingRequestFromCustomer() {
        Scanner scanner = new Scanner(System.in);
        String option = null;
        String additionOption = null;
        
        System.out.print("Enter the type of printing request (document/photo): ");
        String type = scanner.nextLine();

        if (type.equalsIgnoreCase("document")) {
	        System.out.print("Enter the printing option (color/black) : ");
	        option = scanner.nextLine();
        }
        else if (type.equalsIgnoreCase("photo")) {
	        System.out.print("Enter the printing option (normal/passport): ");
	        option = scanner.nextLine();
        }

        System.out.print("Enter the quantity (1-50): ");
        int quantity = scanner.nextInt();
        
        if (type.equalsIgnoreCase("photo")) {
            System.out.print("Enter the addition option (none/HQ/DE/Both): ");
            additionOption = scanner.nextLine();
            
            if(additionOption != null && additionOption == "none") {
            	additionOption = null;
            }
            else {
            	additionOption = null;
            }
        }
        
        return processOrderEntry(type, option, quantity, additionOption);
	}

	public PrintingRequest processOrderEntry(String type, String option, int quantity, String additionOption)
    {
		if(!type.equalsIgnoreCase("document") && !type.equalsIgnoreCase("photo")) {
			throw new IllegalArgumentException("Invalid type: " + type);
		}
		
		if(type.equalsIgnoreCase("document")) {
			if(!option.equalsIgnoreCase("color") && !option.equalsIgnoreCase("black")) {
				throw new IllegalArgumentException("Invalid option: " + option);
			}
		}
		else if(type.equalsIgnoreCase("photo")) {
			if(!option.equalsIgnoreCase("normal") && !option.equalsIgnoreCase("passport")) {
				throw new IllegalArgumentException("Invalid option: " + option);
			}
			else {
				if(additionOption != null && !additionOption.equalsIgnoreCase("hq") && !additionOption.equalsIgnoreCase("de") && !additionOption.equalsIgnoreCase("both")) {
					throw new IllegalArgumentException("Invalid addition option: " + additionOption);
				}
			}
		}
		
		if (quantity < 0 || quantity > 50) {
			throw new IllegalArgumentException("Invalid quantity: " + option);
		}
		
		PrintingRequest request = new PrintingRequest(type, option, quantity, additionOption);
		addPrintingRequest(request);
		return request;
    }
	
	public void addPrintingRequest(PrintingRequest printingRequest) {
		requestList.add(printingRequest);
	}
	
	public void passOrder(Charge charge1) {
		Charge charge = charge1;
		charge.calculateTotalCharge(requestList);
	}
	
	public List<PrintingRequest> getPrintingRequest(){
		return requestList;
	}
}

class PrintingRequest {
	private String type;
    private String option;
    private String additionOption;
    private int quantity;
    
    public PrintingRequest(String type, String option, int quantity, String additionOption) {
    	this.type = type;
        this.option = option;
        this.quantity = quantity;
        this.additionOption = additionOption;
    }

    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }

    public String getOption() {
        return option;
    }
    
    public void setOption(String option) {
        this.option = option;
    }

    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public String getAdditionOption() {
        return additionOption;
    }
    
    public void setAdditionOption(String additionOption) {
    	this.additionOption = additionOption;
    }
}