package my.edu.utar;

import java.util.ArrayList;
import java.util.List;

interface PhotoPrinterFunctionality {
	public void queue(PrintingRequest requestList);
}

class OriPhotoPrinter implements PhotoPrinterFunctionality{
	public void queue(PrintingRequest request) {
    }
}

class PhotoPrinterStub implements PhotoPrinterFunctionality {

    private List<PrintingRequest> queue = new ArrayList<>();

    public void queue(PrintingRequest request) {
        queue.add(request);
    }

    public List<PrintingRequest> getQueue() {
        return queue;
    }
}

public class PhotoPrinter{
	PhotoPrinterFunctionality ppf;
	
	public PhotoPrinter() {
		ppf = new OriPhotoPrinter();
	}
	
	public PhotoPrinter(PhotoPrinterFunctionality ppf) {
		this.ppf = ppf;
	}
	
	public void queueRequest(PrintingRequest requestList) {
		ppf.queue(requestList);
	}
}